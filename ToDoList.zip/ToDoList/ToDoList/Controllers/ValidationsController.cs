using System.Linq;
using Microsoft.AspNetCore.Mvc;
using ToDoList.Models;

namespace ToDoList.Controllers
{
    public class ValidationsController : Controller
    {
        private readonly ToDoListContext _db;

        public ValidationsController(ToDoListContext db)
        {
            _db = db;
        }
        public bool CheckTaskName(string name)
        {
            return !_db.Tasks.Any(u => u.Name.ToUpper() == name.ToUpper());
        }
    }
}