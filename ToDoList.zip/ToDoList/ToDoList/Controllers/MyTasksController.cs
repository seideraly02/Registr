using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using ToDoList.Models;
using ToDoList.ModelsView;

namespace ToDoList.Controllers
{
    public enum Sort
    {
        NameAsc,
        NameDesc,
        PriorityAsc,
        PriorityDesc,
        StatusAsc,
        StatusDesc,
        CreationDateAsc,
        CreationDateDesc,
    }
    public class MyTasksController : Controller
    {
        private ToDoListContext _db;
        private readonly UserManager<IdentityUser> _userManager;

        public MyTasksController(ToDoListContext db, UserManager<IdentityUser> userManager)
        {
            _db = db;
            _userManager = userManager;
        }

        // GET
        public async Task<IActionResult> Index(Sort state = Sort.NameAsc)
        {
            if (User.Identity.IsAuthenticated)
            {
                IQueryable<MyTask> tasks;
                ViewBag.NameSort = state == Sort.NameAsc ? Sort.NameDesc : Sort.NameAsc;
                ViewBag.PrioritySort = state == Sort.PriorityAsc ? Sort.PriorityDesc : Sort.PriorityAsc;
                ViewBag.StatusSort = state == Sort.StatusAsc ? Sort.StatusDesc : Sort.StatusAsc;
                ViewBag.CreationDateSort = state == Sort.CreationDateAsc ? Sort.CreationDateDesc : Sort.CreationDateAsc;
                switch (state)
                {
                    case Sort.NameAsc:
                        tasks = _db.Tasks.OrderBy(t => t.Name);
                        break;
                    case Sort.PriorityAsc:
                        tasks = _db.Tasks.OrderBy(t => t.Priority);
                        break;
                    case Sort.PriorityDesc:
                        tasks = _db.Tasks.OrderByDescending(t => t.Priority);
                        break;
                    case Sort.StatusAsc:
                        tasks = _db.Tasks.OrderBy(t => t.Status);
                        break;
                    case Sort.StatusDesc:
                        tasks = _db.Tasks.OrderByDescending(t => t.Status);
                        break;
                    case Sort.CreationDateAsc:
                        tasks = _db.Tasks.OrderBy(t => t.CreateDateTask);
                        break;
                    case Sort.CreationDateDesc:
                        tasks = _db.Tasks.OrderByDescending(t => t.CreateDateTask);
                        break;
                    default:
                        tasks = _db.Tasks.OrderByDescending(t => t.Name);
                        break;
                }

                IdentityUser user = await _userManager.FindByNameAsync(User.Identity.Name);
                ViewBag.UserId = user.Id;
                return View(tasks.Include(t => t.OpenTaskUser));
            }
            
            return RedirectToAction("Login", "Account");
            
        }
        
        [Authorize]
        public IActionResult Create()
        {
            
            ViewBag.User = _db.Users;
            return View();
        }
        
        [HttpPost]
        public async Task<IActionResult> Create(MyTask task)
        {
            if (ModelState.IsValid)
            {
                IdentityUser user = await _userManager.FindByNameAsync(User.Identity.Name);
                task.CreateTaskUserId = user.Id;
                _db.Tasks.Add(task);
                _db.SaveChanges();
                return RedirectToAction("Index");
            }
            return RedirectToAction("Create");
        }
        
        [Authorize]
        public async Task<IActionResult> UpdateStatus(int? id, Status? status)
        {
            if (id != null)
            {
                MyTask task = _db.Tasks.FirstOrDefault(t => t.Id == id);
                if (task != null)
                {
                    if (status != null)
                    {
                        if (status == Status.Open)
                            task.OpenDateTask = DateTime.Now;
                        if(status == Status.Closed)
                            task.CloseDateTask = DateTime.Now;
                        
                        IdentityUser user = await _userManager.FindByNameAsync(User.Identity.Name);
                        task.OpenTaskUserId = user.Id;
                        task.Status = (Status) status;
                        _db.Tasks.Update(task);
                        _db.SaveChanges();
                        return RedirectToAction("Index");
                    }
                }
            }
            return NotFound();
        }
        
        [Authorize]
        public async Task<IActionResult> Details(int? id)
        {
            if (id != null)
            {
                MyTask myTask = _db.Tasks
                    .Include(t => t.CreateTaskUser)
                    .Include(t=>t.OpenTaskUser)
                    .FirstOrDefault(t => t.Id == id);
                if (myTask != null)
                {
                    IdentityUser user = await _userManager.FindByNameAsync(User.Identity.Name);
                    ViewBag.UserId = user.Id;
                    return View(myTask);
                }
            }
            return NotFound();
        }
        
        [Authorize]
        public async Task<IActionResult> Remove(int id)
        {
            if (id != 0)
            {
                MyTask task = new MyTask {Id = id};
                _db.Entry(task).State = EntityState.Deleted;
                await _db.SaveChangesAsync();
                return RedirectToAction("Index");
            }

            return NotFound();
        }
        
        [Authorize]
        public async Task<IActionResult> Filter(ValueTaskFilter taskFilter, int value)
        {
            IQueryable<MyTask> tasks = _db.Tasks;
            if (taskFilter != null)
            {
                if (taskFilter.Name != null) tasks = tasks.Where(t => t.Name == taskFilter.Name);
                if (taskFilter.CreateDateBefore != null)
                    tasks = tasks.Where(t => t.CreateDateTask > taskFilter.CreateDateBefore);
                if (taskFilter.CreateDateFrom != null)
                    tasks = tasks.Where(t => t.CreateDateTask < taskFilter.CreateDateFrom);
                if (taskFilter.Priority != null) tasks = tasks.Where(t => t.Priority == taskFilter.Priority);
                if (taskFilter.Status != null) tasks = tasks.Where(t => t.Status == taskFilter.Status);
                // if (taskFilter.Words != null) tasks = tasks(t => t.Description).Contains(taskFilter.Words);
            }

            if (value > 0)
            {
                IdentityUser user = await _userManager.FindByNameAsync(User.Identity.Name);
                switch (value)
                {
                    case 1:
                        tasks = _db.Tasks.Where(t => t.OpenTaskUserId == user.Id);
                        break;
                    case 2:
                        tasks = _db.Tasks.Where(t => t.OpenTaskUserId == null);
                        break;
                    case 3:
                        tasks = _db.Tasks.Where(t => t.CreateTaskUserId == user.Id);
                        break;
                }
            }
            return View(nameof(Index),tasks);
        }
    }
}