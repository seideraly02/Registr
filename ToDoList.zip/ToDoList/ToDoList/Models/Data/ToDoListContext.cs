using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace ToDoList.Models
{
    public class ToDoListContext : IdentityDbContext<IdentityUser>
    {
        public DbSet<MyTask> Tasks { get; set; }
        public DbSet<IdentityUser> Users { get; set; }
        public ToDoListContext(DbContextOptions<ToDoListContext> options) : base(options){}
    }

}