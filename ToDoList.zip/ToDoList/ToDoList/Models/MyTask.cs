using System;
using System.ComponentModel.DataAnnotations;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;

namespace ToDoList.Models
{
    public enum Status
    {
        New,
        Open,
        Closed
    }
    public class MyTask
    {
        public int Id { get; set; }
        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        [MinLength(3,ErrorMessage = "Минимальная длина 3 символа")]
        [Remote("CheckTaskName","Validations",ErrorMessage = "Задач с таким названием уже существует")]
        public string Name { get; set; }
        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        public string Priority { get; set; }
        public Status Status { get; set; } = Status.New;
        public DateTime CreateDateTask { get; set; } = DateTime.Now;
        public DateTime OpenDateTask { get; set; }
        public DateTime CloseDateTask { get; set; }
        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        [MinLength(5,ErrorMessage = "Минимальная длина 3 символа")]
        public string Description { get; set; }
        public string CreateTaskUserId { get; set; }
        public IdentityUser CreateTaskUser { get; set; }
        
        public string OpenTaskUserId { get; set; }
        public IdentityUser OpenTaskUser { get; set; }
        
        
    }
}