using System.Threading.Tasks;
using Microsoft.AspNetCore.Identity;

namespace ToDoList.Services
{
    public class RoleInitializer
    {
        public static async Task Initialize(UserManager<IdentityUser> userManager, RoleManager<IdentityRole> roleManager)
        {
            string adminEmail = "admin@admin.com";
            string adminPassword = "admin";
            var roles = new[] {"admin", "user"};
            foreach (var role in roles)
                if (await roleManager.FindByNameAsync(role) is null)
                    await roleManager.CreateAsync(new IdentityRole(role));
            
            if (await userManager.FindByEmailAsync(adminEmail) is null)
            {
                IdentityUser admin = new IdentityUser
                {
                    Email = adminEmail,
                    EmailConfirmed = true,
                    UserName = "admin"
                };
                var result = await userManager.CreateAsync(admin, adminPassword);
                if (result.Succeeded)
                    await userManager.AddToRoleAsync(admin,"admin");
            }
        }
    }
}