using System.ComponentModel.DataAnnotations;

namespace ToDoList.ModelsView
{
    public class RegisterViewModel
    {
        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        [Display(Name = "Email")]
        public string Email { get; set; }

        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        [Display(Name = "Пароль")]
        [DataType(DataType.Password)]
        public string Password { get; set; }
        
        [Required(ErrorMessage = "Поле обязательное для заполнения")]
        [Display(Name = "Пароль")]
        [DataType(DataType.Password)]
        [Compare("Password",ErrorMessage = "Пароли не совпадают")]
        public string ConfPassword { get; set; }

    }
}