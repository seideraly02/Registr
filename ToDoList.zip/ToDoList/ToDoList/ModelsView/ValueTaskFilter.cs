#nullable enable
using System;
using ToDoList.Models;

namespace ToDoList.ModelsView
{
    public class ValueTaskFilter
    {
        public string? Name { get; set; }
        public DateTime? CreateDateFrom { get; set; }
        public DateTime? CreateDateBefore { get; set; }
        public string? Words { get; set; }
        public string? Priority { get; set; }
        public Status? Status { get; set; }
        
    }
}